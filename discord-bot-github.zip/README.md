# Discord Bot

This repository contains a Discord bot (split into multiple files for easier reading + editing).

## Requirements
- Node.js 18+

## Setup
1. Install dependencies:
   ```bash
   npm install
   ```
2. Create a `.env` file (copy from `.env.example`) and put your bot token in it:
   ```env
   TOKEN=...
   ```
3. Start the bot:
   ```bash
   npm start
   ```

## Project structure
- `src/index.js` — entry point (loads `.env`, registers handlers, logs in)
- `src/client.js` — creates the Discord client
- `src/bot.js` — main features + command/event handlers
- `src/postLogin.js` — extra handlers that were below the login line
- `src/utils/` — JSON storage + helpers
- `src/data/` — static autoresponder list

## Security
Never commit your bot token. Keep it in `.env` and ensure `.env` is ignored by git.
